Examples
========

.. toctree::
   :maxdepth: 2
   :caption: Available examples:

   notebooks/Discrete_solver
   notebooks/Scalarizer_and_ScalarSolver