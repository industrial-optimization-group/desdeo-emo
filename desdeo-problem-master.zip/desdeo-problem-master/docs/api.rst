API Documentation
=================

.. automodapi:: desdeo_problem.problem

.. automodapi:: desdeo_problem.testproblems

.. automodapi:: desdeo_problem.surrogatemodels