Examples
========

.. toctree::
   :maxdepth: 2
   :caption: Available examples:

   notebooks/analytical_problem
   notebooks/Defining_a_problem
   notebooks/Benchmark_problems
   notebooks/data_problem
   notebooks/Defining_a_data_based_problem
   notebooks/Lipschitzian_modelling