ExperimentalProblem
===================

.. currentmodule:: desdeo_problem.Problem

.. autoclass:: ExperimentalProblem
   :show-inheritance:

   .. rubric:: Methods Summary

   .. autosummary::

      ~ExperimentalProblem.train
      ~ExperimentalProblem.train_one_objective

   .. rubric:: Methods Documentation

   .. automethod:: train
   .. automethod:: train_one_objective
