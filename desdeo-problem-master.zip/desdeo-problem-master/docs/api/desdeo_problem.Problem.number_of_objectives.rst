number_of_objectives
====================

.. currentmodule:: desdeo_problem.Problem

.. autofunction:: number_of_objectives
