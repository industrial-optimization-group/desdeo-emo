VariableError
=============

.. currentmodule:: desdeo_problem.Variable

.. autoexception:: VariableError
