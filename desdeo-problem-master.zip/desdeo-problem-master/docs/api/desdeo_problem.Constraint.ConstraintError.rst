ConstraintError
===============

.. currentmodule:: desdeo_problem.Constraint

.. autoexception:: ConstraintError
