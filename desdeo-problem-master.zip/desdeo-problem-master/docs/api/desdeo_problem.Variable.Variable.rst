Variable
========

.. currentmodule:: desdeo_problem.Variable

.. autoclass:: Variable
   :show-inheritance:

   .. rubric:: Attributes Summary

   .. autosummary::

      ~Variable.current_value
      ~Variable.initial_value
      ~Variable.name

   .. rubric:: Methods Summary

   .. autosummary::

      ~Variable.get_bounds

   .. rubric:: Attributes Documentation

   .. autoattribute:: current_value
   .. autoattribute:: initial_value
   .. autoattribute:: name

   .. rubric:: Methods Documentation

   .. automethod:: get_bounds
