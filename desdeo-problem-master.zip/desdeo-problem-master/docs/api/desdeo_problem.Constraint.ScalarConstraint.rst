ScalarConstraint
================

.. currentmodule:: desdeo_problem.Constraint

.. autoclass:: ScalarConstraint
   :show-inheritance:

   .. rubric:: Attributes Summary

   .. autosummary::

      ~ScalarConstraint.evaluator
      ~ScalarConstraint.n_decision_vars
      ~ScalarConstraint.n_objective_funs
      ~ScalarConstraint.name

   .. rubric:: Methods Summary

   .. autosummary::

      ~ScalarConstraint.evaluate

   .. rubric:: Attributes Documentation

   .. autoattribute:: evaluator
   .. autoattribute:: n_decision_vars
   .. autoattribute:: n_objective_funs
   .. autoattribute:: name

   .. rubric:: Methods Documentation

   .. automethod:: evaluate
