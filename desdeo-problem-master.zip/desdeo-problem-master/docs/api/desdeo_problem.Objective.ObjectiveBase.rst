ObjectiveBase
=============

.. currentmodule:: desdeo_problem.Objective

.. autoclass:: ObjectiveBase
   :show-inheritance:

   .. rubric:: Methods Summary

   .. autosummary::

      ~ObjectiveBase.evaluate

   .. rubric:: Methods Documentation

   .. automethod:: evaluate
