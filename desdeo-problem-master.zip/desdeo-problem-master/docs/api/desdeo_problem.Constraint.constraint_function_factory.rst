constraint_function_factory
===========================

.. currentmodule:: desdeo_problem.Constraint

.. autofunction:: constraint_function_factory
