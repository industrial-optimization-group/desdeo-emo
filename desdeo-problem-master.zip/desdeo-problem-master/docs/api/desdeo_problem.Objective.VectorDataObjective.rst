VectorDataObjective
===================

.. currentmodule:: desdeo_problem.Objective

.. autoclass:: VectorDataObjective
   :show-inheritance:

   .. rubric:: Methods Summary

   .. autosummary::

      ~VectorDataObjective.train

   .. rubric:: Methods Documentation

   .. automethod:: train
