EvaluationResults
=================

.. currentmodule:: desdeo_problem.Problem

.. autoclass:: EvaluationResults
   :show-inheritance:
