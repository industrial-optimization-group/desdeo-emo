VectorObjectiveBase
===================

.. currentmodule:: desdeo_problem.Objective

.. autoclass:: VectorObjectiveBase
   :show-inheritance:

   .. rubric:: Methods Summary

   .. autosummary::

      ~VectorObjectiveBase.evaluate

   .. rubric:: Methods Documentation

   .. automethod:: evaluate
