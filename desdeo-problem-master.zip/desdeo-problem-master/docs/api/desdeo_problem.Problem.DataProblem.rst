DataProblem
===========

.. currentmodule:: desdeo_problem.Problem

.. autoclass:: DataProblem
   :show-inheritance:

   .. rubric:: Methods Summary

   .. autosummary::

      ~DataProblem.train
      ~DataProblem.train_one_objective

   .. rubric:: Methods Documentation

   .. automethod:: train
   .. automethod:: train_one_objective
