LipschitzianRegressor
=====================

.. currentmodule:: desdeo_problem.surrogatemodels

.. autoclass:: LipschitzianRegressor
   :show-inheritance:

   .. rubric:: Methods Summary

   .. autosummary::

      ~LipschitzianRegressor.distance
      ~LipschitzianRegressor.fit
      ~LipschitzianRegressor.predict
      ~LipschitzianRegressor.self_distance

   .. rubric:: Methods Documentation

   .. automethod:: distance
   .. automethod:: fit
   .. automethod:: predict
   .. automethod:: self_distance
