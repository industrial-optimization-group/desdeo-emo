VectorObjective
===============

.. currentmodule:: desdeo_problem.Objective

.. autoclass:: VectorObjective
   :show-inheritance:

   .. rubric:: Attributes Summary

   .. autosummary::

      ~VectorObjective.evaluator
      ~VectorObjective.lower_bounds
      ~VectorObjective.n_of_objectives
      ~VectorObjective.name
      ~VectorObjective.upper_bounds
      ~VectorObjective.values

   .. rubric:: Attributes Documentation

   .. autoattribute:: evaluator
   .. autoattribute:: lower_bounds
   .. autoattribute:: n_of_objectives
   .. autoattribute:: name
   .. autoattribute:: upper_bounds
   .. autoattribute:: values
