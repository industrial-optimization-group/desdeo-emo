ModelError
==========

.. currentmodule:: desdeo_problem.surrogatemodels

.. autoexception:: ModelError
