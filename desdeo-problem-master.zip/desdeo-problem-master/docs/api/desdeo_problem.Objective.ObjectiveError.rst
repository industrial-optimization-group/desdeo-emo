ObjectiveError
==============

.. currentmodule:: desdeo_problem.Objective

.. autoexception:: ObjectiveError
