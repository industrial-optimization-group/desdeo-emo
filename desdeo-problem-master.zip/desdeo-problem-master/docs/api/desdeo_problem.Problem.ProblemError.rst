ProblemError
============

.. currentmodule:: desdeo_problem.Problem

.. autoexception:: ProblemError
