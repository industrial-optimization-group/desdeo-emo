variable_builder
================

.. currentmodule:: desdeo_problem.Variable

.. autofunction:: variable_builder
