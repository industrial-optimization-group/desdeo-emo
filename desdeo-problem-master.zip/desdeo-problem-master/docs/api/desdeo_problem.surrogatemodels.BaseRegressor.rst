BaseRegressor
=============

.. currentmodule:: desdeo_problem.surrogatemodels

.. autoclass:: BaseRegressor
   :show-inheritance:

   .. rubric:: Methods Summary

   .. autosummary::

      ~BaseRegressor.fit
      ~BaseRegressor.predict

   .. rubric:: Methods Documentation

   .. automethod:: fit
   .. automethod:: predict
