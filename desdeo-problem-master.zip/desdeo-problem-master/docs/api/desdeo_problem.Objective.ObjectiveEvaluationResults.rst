ObjectiveEvaluationResults
==========================

.. currentmodule:: desdeo_problem.Objective

.. autoclass:: ObjectiveEvaluationResults
   :show-inheritance:
