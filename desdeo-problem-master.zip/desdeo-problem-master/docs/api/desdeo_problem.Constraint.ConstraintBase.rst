ConstraintBase
==============

.. currentmodule:: desdeo_problem.Constraint

.. autoclass:: ConstraintBase
   :show-inheritance:

   .. rubric:: Methods Summary

   .. autosummary::

      ~ConstraintBase.evaluate

   .. rubric:: Methods Documentation

   .. automethod:: evaluate
