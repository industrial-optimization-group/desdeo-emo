VariableBuilderError
====================

.. currentmodule:: desdeo_problem.Variable

.. autoexception:: VariableBuilderError
