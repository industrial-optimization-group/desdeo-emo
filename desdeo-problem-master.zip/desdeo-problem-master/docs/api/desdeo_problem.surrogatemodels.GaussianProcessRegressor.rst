GaussianProcessRegressor
========================

.. currentmodule:: desdeo_problem.surrogatemodels

.. autoclass:: GaussianProcessRegressor
   :show-inheritance:

   .. rubric:: Methods Summary

   .. autosummary::

      ~GaussianProcessRegressor.predict

   .. rubric:: Methods Documentation

   .. automethod:: predict
